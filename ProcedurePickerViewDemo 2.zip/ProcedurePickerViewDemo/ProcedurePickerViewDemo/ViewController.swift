//
//  ViewController.swift
//  ProcedurePickerViewDemo
//
//  Created by Dandyala,Harshita on 3/28/22.
//

import UIKit
import AVFoundation;

class ViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        self.alphabet.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        String(Array(alphabet)[row])
    }
    
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.char = String(Array(alphabet)[row])
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        PickerViewOutlet.delegate = self
        PickerViewOutlet.dataSource = self
        self.words.append(Words(token:"swift",clueword: "An ios Programming language"))
        self.words.append(Words(token:"Dog",clueword: "An animal that barks"))
        self.words.append(Words(token:"Delhi",clueword: "Capital of India"))
        self.words.append(Words(token:"Hockey",clueword: "national game of india"))
        self.words.append(Words(token:"Rajamouli",clueword: "Pan India Director"))
        self.words.append(Words(token:"Sundar",clueword: "Google CEO"))
        self.words.append(Words(token:"Dhoni",clueword: "Cricketer with Jersey No.7"))
        self.words.append(Words(token:"Audi",clueword: "Famous Car Compan"))
        self.words.append(Words(token:"ant",clueword: "Small animal name"))
        self.words.append(Words(token:"Netaji",clueword: "Subash chandrabose Other name"))
        // Do any additional setup after loading the view.
        generateRandom()
    }
    var char = ""
    var k:Int = 0
    var result:String = ""
    var emoji = ["🚗","👀","🐍","🐶","🧛‍♀️","🥰","🤓","😆","🧠","💍","🤪","🤭"]
    var words = [Words]()
    let alphabet = "abcdefghijklmnopqrstuvwxyz".uppercased()
  
    

    @IBOutlet weak var GuessWordLBL: UILabel!
    
    @IBOutlet weak var Clue: UILabel!

  
    

    @IBOutlet weak var PickerViewOutlet: UIPickerView!
    
  
    
    @IBOutlet weak var Check: UIButton!
    

    @IBOutlet weak var PlayAgainLBL: UIButton!
    
    
    @IBAction func CheckAction(_ sender: UIButton) {
    
   
        var guessAword = Array(self.GuessWordLBL.text!)
        let result1 = Array(self.result)
        if(result.uppercased().contains(char))
        {
            AudioServicesPlaySystemSound(SystemSoundID(1011))
            for i in 0..<result.count{
                print("p : \(result1[i])")
                if(String(result1[i]).uppercased() == char){
                    guessAword[i] = Character(char)
                }
            }
        }
        else{
            AudioServicesPlaySystemSound(SystemSoundID(1210))
        }
        self.GuessWordLBL.text = String(guessAword)
        if(GuessWordLBL.text! == result.uppercased()){
            let alert = UIAlertController(title: "Congrats!!", message: "Your Guess is correct!!🥳", preferredStyle: .alert)
            let action = UIAlertAction(title: "ok", style: .default, handler: nil)
            alert.addAction(action)
            self.present(alert, animated: true, completion: nil)
            self.Check.isEnabled = false
            self.PlayAgainLBL.isEnabled = true
        }
    }
    
    
    @IBAction func PlayAgainAction(_ sender: UIButton) {
        generateRandom()
    }
    
    
    func random() ->Int{
        return Int (arc4random_uniform (UInt32(words.count)))
    }
    
    func Guess(){
        var a = ""
        for _ in result{
            a += emoji[Int (arc4random_uniform (UInt32(emoji.count)))]
        }
        self.GuessWordLBL.text = a
    }
    
    func generateRandom(){
        k = random()
        self.Clue.text = words[k].clueword
        result = words[k].token
        Guess()
        self.Check.isEnabled = true
        self.PlayAgainLBL.isEnabled = false
    }
    
    struct Words{
        var token: String
        var clueword: String
        
        init(token: String, clueword: String)
        {
            self.token = token
            self.clueword = clueword
        }
    }
}
