//
//  ViewController.swift
//  Dandyala_Calculator
//
//  Created by Dandyala,Harshita on 3/2/22.
//

import UIKit

class ViewController: UIViewController {
    
    var t1: Double = 0.0
    var t2: Double = 0.0
    var sign: String = ""
    var result: Double = 0.0
    
    override func viewDidLoad() {
            super.viewDidLoad()
            resultLabel.text = "0"
            // Do any additional setup after loading the view.
        }

   
    @IBOutlet weak var resultLabel: UILabel!
    
    
    @IBAction func buttonAC(_ sender: UIButton) {
        t1 = 0.0
        t2 = 0.0
        result = 0.0
        clearTextFunction()
        
    }
    
    
    @IBAction func buttonC(_ sender: UIButton) {
                t2=0
        resultLabel.text=""
    }
    
    
    @IBAction func plusMinus(_ sender: UIButton) {
        let display = resultLabel.text!
                let option = display[display.startIndex]
                if(option == "-"){
                    resultLabel.text = resultLabel.text!.replacingOccurrences(of: "-", with: "")
                }
                else{
                    resultLabel.text = "-"+resultLabel.text!
                }
    }
    
    @IBAction func div(_ sender: UIButton) {
        t1 = Double(resultLabel.text!)!
        sign = "/"
        clearTextFunction()
    }
    
    
    @IBAction func button7(_ sender: UIButton) {
        valConvertionFunction(v:"7")
       
    }
    @IBAction func button8(_ sender: UIButton) {
        valConvertionFunction(v:"8")
    }
    @IBAction func button9(_ sender: UIButton) {
        valConvertionFunction(v:"9")
    }
    @IBAction func button6(_ sender: UIButton) {
        valConvertionFunction(v:"6")
    }
    @IBAction func button5(_ sender: UIButton) {
        valConvertionFunction(v:"5")
    }
    @IBAction func button4(_ sender: UIButton) {
        valConvertionFunction(v:"4")
    }
    @IBAction func button3(_ sender: UIButton) {
        valConvertionFunction(v:"3")
    }
    @IBAction func button2(_ sender: UIButton) {
        valConvertionFunction(v:"2")
    }
    @IBAction func button1(_ sender: UIButton) {
        valConvertionFunction(v:"1")
    }
    @IBAction func button0(_ sender: UIButton) {
        valConvertionFunction(v:"0")
    }
    @IBAction func plus(_ sender: UIButton) {
        t1 = Double(resultLabel.text!)!
        sign = "+"
        clearTextFunction()
        
        
    }
    @IBAction func minus(_ sender: UIButton) {
        if(resultLabel.text == "0" || resultLabel.text == ""){
            valConvertionFunction(v:"-")
               }
               else {
        t1 = Double(resultLabel.text!)!
        sign = "-"
        clearTextFunction()
               }
    }
    @IBAction func equalButton(_ sender: UIButton) {
        t2 = Double(resultLabel.text!)!
        switch sign {
                case "+":
                    result = t1+t2
                    rouValueFunction(r:result)
                case "-":
                    result = t1-t2
                    rouValueFunction(r:result)
                case "*":
                    result = t1*t2
                    rouValueFunction(r:result)
                case "/":
                    if(t2 == 0)
                    {
                        resultLabel.text = "Error"
                    }
                    else{
                    result = Double(t1/t2)
                        rouValueFunction(r:round(result * 100000) / 100000.0)
                    }
                case "%":
                    result =  t1.truncatingRemainder(dividingBy: t2)
                    rouValueFunction(r:round(result * 100) / 100.0)
                default:
                    resultLabel.text = "ERROR"
        }
    }
    
    @IBAction func pointButton(_ sender: UIButton) {
        resultLabel.text = resultLabel.text! + "."
    }
    
    
    @IBAction func modButton(_ sender: UIButton) {
        t1 = Double(resultLabel.text!)!
        sign = "%"
        clearTextFunction()
    }
    
    
    @IBAction func multiplyButton(_ sender: UIButton) {
        t1 = Double(resultLabel.text!)!
        sign = "*"
        clearTextFunction()
    }
    
    func clearTextFunction(){
        resultLabel.text = ""
        
    }
    func rouValueFunction(r: Double){
        if(r.truncatingRemainder(dividingBy: 1) == 0.0){
            resultLabel.text = String(Int(r))
                }
                else{
                    resultLabel.text = String(r)
                }
    }
    
    func valConvertionFunction(v: String)
        {
            if(resultLabel.text! == "0")
            {
                resultLabel.text =  v
            }
            else{
                resultLabel.text = resultLabel.text! + v
            }
        }
    
}

