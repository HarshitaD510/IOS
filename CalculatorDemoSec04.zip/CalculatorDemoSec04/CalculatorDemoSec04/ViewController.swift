//
//  ViewController.swift
//  CalculatorDemoSec04
//
//  Created by chandra on 1/31/22.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.resultLBL.text = ""
    }
    
    
    @IBOutlet weak var resultLBL: UILabel!
    
    var operandOne = 0.0
    var operandTwo = 0.0
    var operation = ""
    
    @IBAction func six(_ sender: UIButton) {

        if let titleVal = sender.titleLabel?.text{

            self.resultLBL.text = titleVal

            if self.operandOne == 0.0{

                if let value = Double(titleVal){

                    self.operandOne = value
                }
            }else{
                if let value = Double(titleVal){

                    self.operandTwo = value
                }
            }
        }
    }
    
    @IBAction func fifteen(_ sender: UIButton) {
        
        if let titleVal = sender.titleLabel?.text{

            self.resultLBL.text = titleVal

            if self.operandTwo == 0.0{

                if let value = Double(titleVal){

                    self.operandTwo = value
                }
            }else{
                if let value = Double(titleVal){

                    self.operandOne = value
                }
            }
        }
    }
    
    @IBAction func operation(_ sender: UIButton) {
        
        if let titleVal = sender.titleLabel?.text{

            self.resultLBL.text = titleVal

            self.operation = titleVal
        }
    }
    
    @IBAction func equals(_ sender: UIButton){
        
        if self.operation == "+"{
            
            // self.resultLBL.text = "\(self.operandOne + self.operandTwo)"
            
            self.resultLBL.text = String(format: "%.1f", arguments: [(self.operandTwo + self.operandOne)])
        }
    }
    @IBAction func clear(_ sender: UIButton) {
        
        self.operandOne = 0.0
        self.operandTwo = 0.0
        self.operation = ""
        self.resultLBL.text = ""
    }
}

