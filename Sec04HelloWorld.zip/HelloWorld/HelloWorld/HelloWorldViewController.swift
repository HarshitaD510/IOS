//
//  HelloWorldViewController.swift
//  HelloWorld
//
//  Created by chandra on 1/24/22.
//

import UIKit

class HelloWorldViewController: UIViewController {
    
    @IBOutlet weak var nameTF: UITextField!
    
    @IBOutlet weak var messageLBL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.messageLBL.text = ""
    }
    
    
    @IBAction func greetUser(_ sender: UIButton) {
        
        if let userName = self.nameTF.text, !userName.isEmpty {
            
            self.messageLBL.text = "Hello! \(userName)"
        }
    }
}
