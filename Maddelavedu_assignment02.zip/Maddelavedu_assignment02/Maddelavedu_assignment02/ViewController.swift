//
//  ViewController.swift
//  Maddelavedu_assignment02
//
//  Created by Maddelavedu,Pravallika on 2/3/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var firsttextfield: UITextField!
    
    @IBOutlet weak var fullnamelabel: UILabel!
    
    @IBOutlet weak var initallabel: UILabel!
        
    @IBOutlet weak var lasttextfield: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func submitbutton(_ sender: UIButton) {
        let firstN=firsttextfield.text!
        let lastN=lasttextfield.text!
        fullnamelabel.text="Full Name :\(lastN),\(firstN)"
        let fn = firstN.first!
        let ln = lastN.first!
        initallabel.text = "initials: \(fn)\(ln)"
        
    }
    
    @IBAction func resetbutton(_ sender: UIButton) {
        firsttextfield.text = " "
        lasttextfield.text = " "
        fullnamelabel.text = " "
        initallabel.text = " "
        firsttextfield.becomeFirstResponder()
    }
    
    
}

